# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 22:48:20 2019

@author: ego_c
"""

#1.- Numpy with wine

#data set - https://archive.ics.uci.edu/ml/datasets/Wine+Quality
#we will use winequality-red.csv

# Import the csv library
import csv

# With the file open, create a new csv.reader object
with open("winequality-red.csv", 'r') as f:
    wines = list(csv.reader(f, delimiter=";"))
    # Pass in the keyword argument delimiter=";" to make sure that the records are split up on the 
    # semicolon character instead of the default comma character
    
print(wines[:2])

qualities = [float(item[-1]) for item in wines[1:]]  
sum(qualities) / len(qualities)

# Although we were able to do the calculation we wanted, the code is fairly complex, and it won’t be fun 
# to have to do something similar every time we want to compute a quantity

# we can use NumPy to make it easier to work with our data.

#2.- Numpy 2-Dimensional Arrays
#Creating A NumPy Array

# numpy.array() - If we pass in a list of lists, it will automatically create a NumPy array 
# with the same number of rows and columns

# Because we want all of the elements in the array to be float elements for easy computation, 
# we’ll leave off the header row, which contains strings. 

# One of the limitations of NumPy is that all the elements in an array have to be of the same type, 
# so if we include the header row, all the elements in the array will be read in as strings. 

# Because we want to be able to do computations like find the average quality of the wines, 
# we need the elements to all be floats.

import numpy as np
wines = np.array(wines[1:], dtype=np.float)

# Pass the list of lists wines into the array function, which converts it into a NumPy array
# Exclude the header row with list slicing
# Specify the keyword argument dtype to make sure each element is converted to a float
wines
# We can check the number of rows and columns in our data using the shape property of NumPy arrays
wines.shape

#3.- Alternative array creation methods

# It’s useful to create an array with all zero elements in cases when you need an array of fixed size, 
# but don’t have any values for it yet
empty_array = np.zeros((3,4))
empty_array

# Creating arrays full of random numbers can be useful when you want to quickly test your code with sample arrays
np.random.rand(3,4)

#4.- Using NumPy To Read In Files

wines = np.genfromtxt("winequality-red.csv", delimiter=";", skip_header=1)
wines

# can use array indexing to select individual elements, groups of elements, or entire rows and columns
# NumPy is zero-indexed, meaning that the index of the first row is 0, and the index of the first column is 0

# so to select the element at row 3 and column 2
wines[2,1]

#5.- Slicing NumPy Arrays

# select the first three items from the third column
wines[0:3,2]

wines[:3,2] # it’s possible to omit the 0 to just retrieve all the elements from the beginning up to element 2

# select the entire third column
wines[:,2]

# we can also extract an entire first row
wines[0,:]

#6.- Assigning Values To NumPy Arrays

# use indexing to assign values to certain elements in arrays
wines[1,5] = 10

# To overwrite an entire column, we can do this
wines[:,10] = 50

#7.- 1-Dimensional NumPy Arrays

# slice wines and only retrieve the third row
third_wine = wines[3,:]
third_wine

# retrieve quality of third wine
qual_w3=third_wine[-1]
qual_w3

# could have done this on wine 2d array also
qual_w3_v2=wines[3,-1]
qual_w3_v2

#8.- Single Array Math

# add 10 points to each quality score
wines[:,11] + 10

# the above operation won’t change the wines array – it will return a new 1-d array
# where 10 has been added to each element in the quality column of wines

# however, the following code will modify the array
wines[:,11] += 10
wines[:,11]

#9.- Multiple Array Math

# if we add the quality column to itself
wines[:,11] + wines[:,11]

# Let’s say we want to pick a wine that maximizes alcohol content and quality

# We’d multiply alcohol by quality, and select the wine with the highest score
wines[:,10] * wines[:,11]

#10.- array methods

# total of all of our quality ratings
wines[:,11].sum()

wines.sum(axis=0) # specified axis is the one “going away”
# shape should be 12, corresponding to the number of columns - hence, the rows gone away

wines.sum(axis=1)

wines.mean(axis=0) # finds the mean of all cols

wines.std(axis=0) # finds the sd of all cols

wines.min(axis=0) # finds the min of all cols

wines.max(axis=0) # finds the max of all cols

#11.- NumPy Array Comparisons

# we want to see which wines have a quality rating higher than 5
wines[:,11] > 5

# see if any wines have a quality rating equal to 10
wines[:,11] == 10

#12.- plotting using matplotlib

import numpy as np
import matplotlib.pyplot as plt

# Compute the x and y coordinates for points on a sine curve
x = np.arange(0, 3 * np.pi, 0.1)
y = np.sin(x)

# Plot the points using matplotlib
plt.plot(x, y)
plt.show()  # You must call plt.show() to make graphics appear.

import numpy as np
import matplotlib.pyplot as plt

# Compute the x and y coordinates for points on sine and cosine curves
x = np.arange(0, 3 * np.pi, 0.1)
y_sin = np.sin(x)
y_cos = np.cos(x)

# Plot the points using matplotlib
plt.plot(x, y_sin)
plt.plot(x, y_cos)
plt.xlabel('x axis label')
plt.ylabel('y axis label')
plt.title('Sine and Cosine')
plt.legend(['Sine', 'Cosine'])
plt.show()

# Set up a subplot grid that has height 2 and width 1,
# and set the first such subplot as active.
# Compute the x and y coordinates for points on sine and cosine curves

import numpy as np
import matplotlib.pyplot as plt
x = np.arange(0, 3 * np.pi, 0.1)
y_sin = np.sin(x)
y_cos = np.cos(x)

plt.subplot(2, 1, 1)
# Make the first plot
plt.plot(x, y_sin)
plt.title('Sine')
# Set the second subplot as active, and make the second plot.
plt.subplot(2, 1, 2)
plt.plot(x, y_cos)
plt.title('Cosine')
# Show the figure.
plt.show()