# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 23:06:44 2019

@author: ego_c
"""

#1.- Accessing array elements - indexing and slicing - colon notation

import numpy as np

# create array of squares of 0-12
s=np.arange(13)**2
s

# we can use [] notation to get the value at a particular index
s[4]   # first value is at position 0

# colon notation to get a range
# notation is starting index, ending index and step size
# specifying the starting or ending index is not necessary
# we can also use negatives to count back from the end of the array  

# a[start:end] - items start through end-1
s[0:3]  

# a[:end] - items from the beginning through end-1
s[:3] # this is same as s[0:3]   

# a[start:] - items start through the rest of the array
s[3:]

# a[:] - a copy of the whole array
s[:]

# a[start:end:step] - start through not past end, by step
s[::2]

s[:5:2]

# a[-1] - last item in the array
s[-1]

s[-1:] # slice of last 1 element of the array

s[-4] # 4th last item in the array

s[-4:] # slice of last 4 elements of the array

s[-5::-2] #starting 5th from the end to the beginning of the array and counting backwards by 2

s[-1:]

# a[:-2] - everything except the last two items
s[:-2]

#2.- lets see how this extends to a 2 dimensional array

# lets create a 2 dimensional array from 0-35 and resize it as 6x6
r=np.arange(36)
r.resize((6,6))
r

r[2,2] # 14 is the value at second row second column

r[3,3:6] # colon notation used to get a slice of 3rd row column 3-6

r[:2,:-1] # first two rows and all the columns except the last

r[-1,::2] # select every second element from the last row

r[r>30] # use bracket operator to do conditional indexing and assignment

r[r>30]=30 # capping the max value of elements in the array to 30
r

#3.- Copying data

# first lets create a new array r2 which is the slice of the array r
r2=r[:3,:3]
r2

r2[:]=0 # sets all elements of this array to 0
r2

# now if we look at the original array r, we see that the slice of data in the original array has also been changed
# this is something to keep in mind and be careful about when working with numpy arrays
r

# copy can be used to avoid this
r_copy=r.copy()
r_copy[:]=10
r_copy

r # values of r are still intact

#4.- Iterating over arrays

# first lets create a 4x3 array of random nubers from 0-9
test=np.random.randint(0,10,(4,3))
test

# iterate by row
for row in test:
    print (row)
        
# iterate by row index using the length function on test which returns the number of rows
for i in range(len(test)):
    print (test[i])

# we can combine these two ways of iterating by using enumerate, which gives us the row and the index of the row
for i,row in enumerate(test):
    print('row',i,'is',row)  
    
# zip
test2=test**2
print(test2)
# if we wish to iterate through both arrays we can use zip
for i,j in zip(test,test2):
    print(i,'+',j,'=',i+j)
    
#5.- range function explained

# range(stop) - number of integers to generate starting from zero, for example range(3) == [0,1,2]

# range(start,stop,step)
# Start is the starting number of the sequence, 
# generate number up to but not including stop, 
# Step is the difference between each number in the sequence
for i in range(3):
    print(i)

for i in range(3,6):
    print(i)

for i in range(4,10,2):
    print(i)

for i in range(0,-8,-2):
    print(i)

# Thank you!