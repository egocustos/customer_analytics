# Natural Language Processing

# Importing the dataset
dataset_original = read.delim('Restaurant_Reviews.tsv', quote = '', stringsAsFactors = FALSE)

# Cleaning the texts
# install.packages('tm')
# install.packages('SnowballC')
library(tm) #Famous NLP Library in R
library(SnowballC) #For stopwords function
corpus = VCorpus(VectorSource(dataset_original$Review))
corpus = tm_map(corpus, content_transformer(tolower))
corpus = tm_map(corpus, removeNumbers)
corpus = tm_map(corpus, removePunctuation)
corpus = tm_map(corpus, removeWords, stopwords())
corpus = tm_map(corpus, stemDocument)
corpus = tm_map(corpus, stripWhitespace)

# Creating the Bag of Words model
dtm = DocumentTermMatrix(corpus) 
#Keeping 99.9% of the most frequent words
dtm = removeSparseTerms(dtm, 0.999)
#Generate the Sparse Matrix
dataset = as.data.frame(as.matrix(dtm))
dataset$Liked = dataset_original$Liked
# Encoding the target feature as factor
dataset$Liked = factor(dataset$Liked, levels = c(0, 1))

# Splitting the dataset into the Training set and Test set
# install.packages('caTools')
library(caTools)
set.seed(123)
split = sample.split(dataset$Liked, SplitRatio = 0.8)
training_set = subset(dataset, split == TRUE)
test_set = subset(dataset, split == FALSE)

##### Logistic Regression ####
# Fitting Logistic Regression to the Training set
classifier = glm(formula = Liked ~ .,
                 family = binomial,
                 data = training_set)

# Predicting the Test set results
prob_pred = predict(classifier, type = 'response', newdata = test_set[-692])
y_pred_lr = ifelse(prob_pred > 0.5, 1, 0)

# Making the Confusion Matrix
cm_lr = table(test_set[, 692], y_pred_lr > 0.5)


##### Decision Trees ####
# Fitting Decision Tree Classification to the Training set
# install.packages('rpart')
library(rpart)
classifier_dt = rpart(formula = Liked ~ .,
                      data = training_set)

# Predicting the Test set results
y_pred_dt = predict(classifier_dt, newdata = test_set[-692], type = 'class')

# Making the Confusion Matrix
cm_dt = table(test_set[, 692], y_pred_dt)

##### Random Forest #####
# Fitting Random Forest Classification to the Training set
# install.packages('randomForest')
library(randomForest)
classifier_rf = randomForest(x = training_set[-692],
                          y = training_set$Liked,
                          ntree = 10)

# Predicting the Test set results
y_pred_rf = predict(classifier_rf, newdata = test_set[-692])

# Making the Confusion Matrix
cm_rf = table(test_set[, 692], y_pred_rf)

##### Naive Bayes ####
# install.packages('e1071')
library(e1071)
classifier_nb = naiveBayes(x = training_set[-692],
                        y = training_set$Liked)

# Predicting the Test set results
y_pred_nb = predict(classifier_nb, newdata = test_set[-692])

# Making the Confusion Matrix
cm_nb = table(test_set[, 692], y_pred_nb)



